import * as React from "react";
import { useState } from "react";
import { ScrollView, View, Dimensions, StyleSheet } from "react-native";
import Carousel from "react-native-reanimated-carousel";
import FrameComponent2 from "../components/FrameComponent2";
import FrameComponent1 from "../components/FrameComponent1";
import FrameComponent from "../components/FrameComponent";
import FrameComponent5 from "../components/FrameComponent5";
import FrameComponent4 from "../components/FrameComponent4";
import FrameComponent3 from "../components/FrameComponent3";
import FrameComponent8 from "../components/FrameComponent8";
import FrameComponent7 from "../components/FrameComponent7";
import FrameComponent6 from "../components/FrameComponent6";
import { Margin, Padding, Color } from "../GlobalStyles";

const IPhone1313Pro109 = () => {
  const [frameCarouselItems, setFrameCarouselItems] = useState([
    <FrameComponent2 />,
    <FrameComponent1 />,
    <FrameComponent />,
  ]);
  const [frameCarousel1Items, setFrameCarousel1Items] = useState([
    <FrameComponent5 />,
    <FrameComponent4 />,
    <FrameComponent3 />,
  ]);
  const [frameCarousel2Items, setFrameCarousel2Items] = useState([
    <FrameComponent8 />,
    <FrameComponent7 />,
    <FrameComponent6 />,
  ]);

  return (
    <View style={styles.iphone1313Pro109}>
      <ScrollView
        style={styles.frameParent}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.frameScrollViewContent}
      >
        <View
          style={[
            styles.frameWrapper,
            styles.frameSpaceBlock,
            styles.wrapperLayout,
          ]}
        >
          <View
            style={[styles.wrapper, styles.frameLayout1, styles.wrapperLayout]}
          >
            <Carousel
              width={220}
              height={42}
              vertical="true"
              mode="stack-vertical-left"
              data={frameCarouselItems}
              renderItem={({ item }) => item}
            />
          </View>
        </View>
        <View
          style={[styles.frameContainer, styles.mt_13, styles.frameSpaceBlock]}
        >
          <View style={styles.container}>
            <Carousel
              width={Dimensions.get("window").width * 0.86}
              height={52}
              vertical="true"
              mode="stack-vertical-left"
              data={frameCarousel1Items}
              renderItem={({ item }) => item}
            />
          </View>
        </View>
        <View
          style={[styles.frameLayout, styles.mt_13, styles.frameSpaceBlock]}
        >
          <View style={[styles.frame, styles.frameLayout, styles.frameLayout1]}>
            <Carousel
              width={220}
              height={50}
              vertical="true"
              mode="stack-vertical-left"
              data={frameCarousel2Items}
              renderItem={({ item }) => item}
            />
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  mt_13: {
    marginTop: Margin.m_md,
  },
  frameScrollViewContent: {
    flexDirection: "column",
    paddingHorizontal: 0,
    paddingVertical: 20,
  },
  frameSpaceBlock: {
    paddingVertical: 0,
    paddingHorizontal: Padding.p_md,
    backgroundColor: Color.silver,
    alignSelf: "stretch",
  },
  wrapperLayout: {
    height: 42,
    alignItems: "center",
  },
  frameLayout1: {
    width: 220,
    backgroundColor: Color.gray,
  },
  frameLayout: {
    height: 50,
    alignItems: "center",
    overflow: "hidden",
  },
  wrapper: {
    alignItems: "center",
  },
  frameWrapper: {
    alignItems: "center",
    overflow: "hidden",
  },
  container: {
    height: 52,
    padding: Padding.p_sm,
    backgroundColor: Color.gray,
    alignItems: "center",
    alignSelf: "stretch",
    overflow: "hidden",
  },
  frameContainer: {
    height: 53,
    justifyContent: "space-between",
    alignItems: "center",
    overflow: "hidden",
  },
  frame: {
    paddingHorizontal: 0,
    paddingVertical: Padding.p_sm,
  },
  frameParent: {
    position: "absolute",
    marginTop: -79.5,
    top: "50%",
    right: 0,
    left: 0,
    backgroundColor: "#f8f8f8",
    overflow: "hidden",
    flex: 1,
  },
  iphone1313Pro109: {
    borderRadius: 40,
    backgroundColor: "#fff",
    width: "100%",
    height: 811,
    flex: 1,
  },
});

export default IPhone1313Pro109;
