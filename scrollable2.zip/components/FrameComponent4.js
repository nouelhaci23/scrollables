import * as React from "react";
import { StyleProp, ViewStyle, Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const FrameComponent4 = ({ style }) => {
  return (
    <View style={[styles.fundraisingEventsParent, style]}>
      <Text style={styles.fundraisingEvents}>Fundraising Events</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  fundraisingEvents: {
    position: "absolute",
    top: -1,
    left: 1,
    fontSize: FontSize.size_lg,
    fontWeight: "800",
    fontFamily: FontFamily.poppinsExtrabold,
    color: Color.darkslateblue,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: 33,
    width: 333,
  },
  fundraisingEventsParent: {
    borderRadius: Border.br_md,
    backgroundColor: Color.blanchedalmond,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    height: 32,
    overflow: "hidden",
    width: 333,
  },
});

export default FrameComponent4;
