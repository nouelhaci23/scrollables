import * as React from "react";
import { StyleProp, ViewStyle, Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const FrameComponent7 = ({ style }) => {
  return (
    <View style={[styles.foodDistributionParent, style]}>
      <Text style={styles.foodDistribution}>FOOD DISTRIBUTION</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  foodDistribution: {
    position: "absolute",
    top: 5,
    left: 1,
    fontSize: FontSize.size_base,
    fontWeight: "800",
    fontFamily: FontFamily.poppinsExtrabold,
    color: Color.black,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 221,
  },
  foodDistributionParent: {
    borderRadius: Border.br_md,
    backgroundColor: Color.blanchedalmond,
    height: 32,
    overflow: "hidden",
    width: 221,
  },
});

export default FrameComponent7;
