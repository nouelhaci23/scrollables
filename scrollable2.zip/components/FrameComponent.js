import * as React from "react";
import { StyleProp, ViewStyle, Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const FrameComponent = ({ style }) => {
  return (
    <View style={[styles.fundraisingEventsParent, style]}>
      <Text style={styles.fundraisingEvents}>{`Fundraising Events `}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  fundraisingEvents: {
    position: "absolute",
    top: 5,
    left: 1,
    fontSize: FontSize.size_base,
    fontWeight: "800",
    fontFamily: FontFamily.poppinsExtrabold,
    color: Color.black,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 221,
  },
  fundraisingEventsParent: {
    borderRadius: Border.br_md,
    backgroundColor: Color.blanchedalmond,
    height: 32,
    overflow: "hidden",
    width: 221,
  },
});

export default FrameComponent;
