import * as React from "react";
import { StyleProp, ViewStyle, Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const FrameComponent3 = ({ style }) => {
  return (
    <View style={[styles.homelessShelterParent, style]}>
      <Text style={styles.homelessShelter}>HOMELESS SHELTER</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  homelessShelter: {
    position: "absolute",
    top: -1,
    left: 1,
    fontSize: FontSize.size_lg,
    fontWeight: "800",
    fontFamily: FontFamily.poppinsExtrabold,
    color: Color.darkslateblue,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: 33,
    width: 333,
  },
  homelessShelterParent: {
    borderRadius: Border.br_md,
    backgroundColor: Color.blanchedalmond,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    height: 32,
    overflow: "hidden",
    width: 333,
  },
});

export default FrameComponent3;
