import * as React from "react";
import { StyleProp, ViewStyle, Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const FrameComponent2 = ({ style }) => {
  return (
    <View style={[styles.homelessShelterParent, style]}>
      <Text style={styles.homelessShelter}>{`HOMELESS SHELTER `}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  homelessShelter: {
    position: "absolute",
    top: 4,
    left: 0,
    fontSize: FontSize.size_base,
    fontWeight: "800",
    fontFamily: FontFamily.poppinsExtrabold,
    color: Color.black,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 221,
  },
  homelessShelterParent: {
    borderRadius: Border.br_md,
    backgroundColor: Color.blanchedalmond,
    height: 32,
    overflow: "hidden",
    width: 221,
  },
});

export default FrameComponent2;
