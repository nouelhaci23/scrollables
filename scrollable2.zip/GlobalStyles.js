/* fonts */
export const FontFamily = {
  poppinsExtrabold: "Poppins_extrabold",
};
/* font sizes */
export const FontSize = {
  size_base: 16,
  size_lg: 24,
};
/* Colors */
export const Color = {
  blanchedalmond: "#f8e3ca",
  black: "#000",
  darkslateblue: "#6d62b4",
  silver: "rgba(211, 195, 195, 0)",
  gray: "rgba(255, 255, 255, 0)",
};
/* Paddings */
export const Padding = {
  p_sm: 10,
  p_md: 28,
};
/* Margins */
export const Margin = {
  m_md: -13,
};
/* border radiuses */
export const Border = {
  br_md: 5,
};
