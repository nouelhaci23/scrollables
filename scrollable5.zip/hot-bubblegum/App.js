import React, { Component } from "react";
import { WheelPicker, Item } from "react-native-android-wheel-picker";
import { View, StyleSheet } from "react-native";

export default class ExamplePicker extends Component {
  constructor(props) {
    super(props);

    this.state = {
      selected: "js",
    };
  }

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.pickerContainer}>
          <WheelPicker
            selectedValue={this.state.selected}
            onValueChange={(value) => this.setState({ selected: value })}
            backgroundColor="white"
            itemStyle={{ color: "#0B0889" }}
          >
            <Item label="11 AM - NOT AVAILABLE" value="py" />
            <Item label="12 PM - AVAILABLE" value="c" />
            <Item label="1 PM - NOT AVAILABLE" value="js" />
            <Item label="2 pm - AVAILABLE" value="ru" />
            <Item label="3 PM - NOT AVAILABLE" value="etc" />
          </WheelPicker>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  pickerContainer: {
     height: 120,
    width: 250,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
  },
});
