import React, { Component } from "react";
import { WheelPicker, Item } from "react-native-android-wheel-picker";
import { View, StyleSheet } from "react-native";

export default class ExamplePicker extends Component {
  constructor(props) {
    super(props);

    this.state = {
      selected: "js",
    };
  }

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.pickerContainer}>
          <View style={styles.middleContainer} />
          <WheelPicker
            selectedValue={this.state.selected}
            onValueChange={(value) => this.setState({ selected: value })}
            backgroundColor=""
            itemStyle={{ color: "white", width: 166, marginBottom: -4, height:35, margintop: -4 }}
          >
            <Item label="Python" value="py" />
            <Item label="C++" value="c" />
            <Item label="JavaScript" value="js" />
            <Item label="Ruby" value="ru" />
            <Item label="Other" value="etc" />
          </WheelPicker>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  pickerContainer: {
    height: 105,
    width: 166,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 10,
    borderWidth: 0,
    backgroundColor: '#F07E2B'
  },
  middleContainer: {
    height: 38,
    width: "100%",
    backgroundColor: "#E25F00",
    position: "absolute",
    top: "48%",
    marginTop: -17.5,
    
  },
});
